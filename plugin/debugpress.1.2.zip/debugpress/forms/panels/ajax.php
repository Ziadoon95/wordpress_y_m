<div class="debugpress-grid">
    <div class="debugpress-unit full">
        <div id="debugpress-debugger-ajax-wrapper" data-calls="0">
			<?php _e( "There are no AJAX requests detected yet.", "debugpress" ); ?>
        </div>
    </div>
</div>