<?php

use Dev4Press\Plugin\DebugPress\Panel\DoingItWrong;

?>
<div class="debugpress-grid">
    <div class="debugpress-unit full">
		<?php DoingItWrong::instance()->single(); ?>
    </div>
</div>
